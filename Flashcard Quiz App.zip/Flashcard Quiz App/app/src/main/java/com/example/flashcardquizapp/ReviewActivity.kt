package com.example.flashcardquizapp

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ReviewActivity : AppCompatActivity() {

    private lateinit var scoreTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_review)

        scoreTextView = findViewById(R.id.score_text_view)

        val score = intent.getIntExtra("SCORE", 0)
        scoreTextView.text = "Your score: $score"
    }
}
