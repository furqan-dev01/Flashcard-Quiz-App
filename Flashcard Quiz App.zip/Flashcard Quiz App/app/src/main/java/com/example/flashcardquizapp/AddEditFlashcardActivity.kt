package com.example.flashcardquizapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class AddEditFlashcardActivity : AppCompatActivity() {

    private lateinit var questionEditText: EditText
    private lateinit var answerEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_edit_flashcard)

        questionEditText = findViewById(R.id.edit_text_question)
        answerEditText = findViewById(R.id.edit_text_answer)
        saveButton = findViewById(R.id.button_save)
        firestore = FirebaseFirestore.getInstance()

        val deckId = intent.getStringExtra("deckId") ?: return

        saveButton.setOnClickListener {
            val question = questionEditText.text.toString().trim()
            val answer = answerEditText.text.toString().trim()
            if (question.isNotEmpty() && answer.isNotEmpty()) {
                val flashcard = Flashcard(question = question, answer = answer)
                firestore.collection("decks").document(deckId).collection("flashcards").add(flashcard)
                    .addOnSuccessListener {
                        finish()
                    }
            }
        }
    }
}
