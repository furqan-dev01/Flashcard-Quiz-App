package com.example.flashcardquizapp

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class QuizActivity : AppCompatActivity() {

    private lateinit var firestore: FirebaseFirestore
    private lateinit var questionTextView: TextView
    private lateinit var answerEditText: EditText
    private lateinit var submitButton: Button
    private var currentIndex = 0
    private var score = 0
    private var flashcards = mutableListOf<Flashcard>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        firestore = FirebaseFirestore.getInstance()
        questionTextView = findViewById(R.id.question_text_view)
        answerEditText = findViewById(R.id.answer_edit_text)
        submitButton = findViewById(R.id.submit_button)

        val deckId = intent.getStringExtra("deckId")
        if (deckId != null) {
            loadFlashcards(deckId)
        } else {
            handleMissingDeckId()
        }

        submitButton.setOnClickListener {
            checkAnswer()
        }
    }

    private fun loadFlashcards(deckId: String) {
        firestore.collection("decks").document(deckId).collection("flashcards")
            .get()
            .addOnSuccessListener { result ->
                flashcards = result.mapNotNull { document ->
                    val question = document.getString("question")
                    val answer = document.getString("answer")
                    if (question != null && answer != null) {
                        Flashcard(document.id, question, answer)
                    } else {
                        Log.e("QuizActivity", "Missing question or answer in document ${document.id}")
                        null
                    }
                }.toMutableList()

                if (flashcards.isNotEmpty()) {
                    showQuestion()
                } else {
                    handleEmptyFlashcardsList()
                }
            }
            .addOnFailureListener { exception ->
                Log.e("QuizActivity", "Error loading flashcards", exception)
                handleFirestoreError(exception)
            }
    }

    private fun showQuestion() {
        if (currentIndex < flashcards.size) {
            questionTextView.text = flashcards[currentIndex].question
        } else {
            // Quiz is complete, show the score
            val intent = Intent(this, ReviewActivity::class.java)
            intent.putExtra("SCORE", score)
            startActivity(intent)
            finish()
        }
    }

    private fun checkAnswer() {
        val userAnswer = answerEditText.text.toString().trim()
        val correctAnswer = flashcards.getOrNull(currentIndex)?.answer ?: ""
        if (userAnswer.equals(correctAnswer, ignoreCase = true)) {
            score++
        }
        currentIndex++
        showQuestion()
        answerEditText.setText("");
    }

    private fun handleMissingDeckId() {
        Toast.makeText(this, "Deck ID is missing. Please try again.", Toast.LENGTH_LONG).show()
        finish()
    }

    private fun handleEmptyFlashcardsList() {
        Toast.makeText(this, "No flashcards found for this deck.", Toast.LENGTH_LONG).show()
        finish()
    }

    private fun handleFirestoreError(exception: Exception) {
        Toast.makeText(this, "Error loading flashcards: ${exception.localizedMessage}", Toast.LENGTH_LONG).show()
    }
}
