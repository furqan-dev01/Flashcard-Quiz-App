package com.example.flashcardquizapp

data class Flashcard(
    var id: String? = null,
    var question: String? = null,
    var answer: String? = null
)
