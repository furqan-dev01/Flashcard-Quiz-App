package com.example.flashcardquizapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.android.material.floatingactionbutton.FloatingActionButton

class FlashcardsActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: FlashcardAdapter
    private lateinit var firestore: FirebaseFirestore
    private var flashcardsListener: ListenerRegistration? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_flashcards)

        firestore = FirebaseFirestore.getInstance()

        recyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = FlashcardAdapter(mutableListOf())
        recyclerView.adapter = adapter

        findViewById<FloatingActionButton>(R.id.fab_add_flashcard).setOnClickListener {
            val deckId = intent.getStringExtra("deckId")
            val intent = Intent(this, AddEditFlashcardActivity::class.java).apply {
                putExtra("deckId", deckId)
            }
            startActivity(intent)
        }

        val deckId = intent.getStringExtra("deckId") ?: return
        loadFlashcards(deckId)

        findViewById<FloatingActionButton>(R.id.fab_quiz_flashcard).setOnClickListener {
            val deckId = intent.getStringExtra("deckId")
            val intent = Intent(this, QuizActivity::class.java).apply {
                putExtra("deckId", deckId)
            }
            startActivity(intent)
        }

    }

    private fun loadFlashcards(deckId: String) {
        flashcardsListener = firestore.collection("decks").document(deckId).collection("flashcards")
            .addSnapshotListener { snapshots, e ->
                if (e != null) {
                    return@addSnapshotListener
                }

                val flashcards = mutableListOf<Flashcard>()
                for (doc in snapshots!!) {
                    val flashcard = doc.toObject(Flashcard::class.java)
                    flashcard.id = doc.id
                    flashcards.add(flashcard)
                }
                adapter.setFlashcards(flashcards)
            }
    }

    override fun onDestroy() {
        super.onDestroy()
        flashcardsListener?.remove()
    }
}
