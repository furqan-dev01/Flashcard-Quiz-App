package com.example.flashcardquizapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class AddEditDeckActivity : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_edit_deck)

        nameEditText = findViewById(R.id.edit_text_name)
        saveButton = findViewById(R.id.button_save)
        firestore = FirebaseFirestore.getInstance()

        saveButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            if (name.isNotEmpty()) {
                val deck = Deck(name = name)
                firestore.collection("decks").add(deck)
                    .addOnSuccessListener {
                        finish()
                    }
            }
        }
    }
}
