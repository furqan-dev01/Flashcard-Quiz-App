package com.example.flashcardquizapp

data class Deck(
    var id: String? = null,
    var name: String? = null // Add other fields as required
)
